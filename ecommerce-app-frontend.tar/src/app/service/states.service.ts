import { Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class StatesService {
  loginError = signal({ text: '', status: -1 });
  pinCodeList = signal([{ pincode: '', days: -1 }]);
  showModal = signal(false);
  serviceMessage = signal({text: ''});
  productID = signal(-1);
  productPbList = signal([{
    productName: '',
    productCode: -1,
    brand: ''
  }])
  productList = signal([
    {
      productID: 0,
      productName: '',
      productCode: -1,
      brand: '',
      seller: false,
      user: {
        username: '',
        firstName: '',
        lastName: '',
        emailId: '',
      },
      details: {
        productDetailID: 0,
        price: -1,
        description: '',
        image: '',
      },
      pincodeList: [
        {
          pincode: -1,
          days: -1,
        },
      ],
    },
  ]);

  constructor() {}
}
