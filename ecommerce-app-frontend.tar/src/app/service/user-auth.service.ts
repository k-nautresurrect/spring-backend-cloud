import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  Router,
  RouterStateSnapshot,
} from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class UserAuthService {
  constructor(private router: Router) {}

  public canActivate(
    r: ActivatedRouteSnapshot,
    s: RouterStateSnapshot
  ): boolean {
    if (this.getToken() === null) {
      this.router.navigateByUrl('/login');
      return false;
    }
    const role: string = this.getRole() as string;
    const allowedRole: string = r.data['role'];
    if (role === allowedRole) {
      return true;
    }
    this.router.navigateByUrl('/forbidden');
    return false;
  }

  public isLoggedIn(): boolean{
    return (this.getToken()!==null && this.getRole() !== null);
  }

  public getToken(): string|null {
    const jsonString: string = localStorage.getItem('user') as string;
    if(jsonString === null){
      return null;
    }
    const { token } = JSON.parse(jsonString);
    return token.token;
  }

  public getRole(): string|null {
    const jsonString: string = localStorage.getItem('user') as string;
    if(jsonString === null){
      return null;
    }
    const { userDetails } = JSON.parse(jsonString);
    return userDetails.role;
  }

  public logout() {
    localStorage.removeItem("user");
  }

  public getUserName() {
    const jsonString: string = localStorage.getItem('user') as string;
    const { userDetails } = JSON.parse(jsonString);

    const name = userDetails.firstName + " " + userDetails.lastName;
    return name;
  }
}
