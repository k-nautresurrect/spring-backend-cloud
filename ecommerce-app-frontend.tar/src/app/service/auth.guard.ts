import { inject } from '@angular/core';
import { CanActivateFn } from '@angular/router';
import { UserAuthService } from './user-auth.service';

export const authGuard: CanActivateFn = (route, state) => {
  return inject(UserAuthService).canActivate(route, state);
};