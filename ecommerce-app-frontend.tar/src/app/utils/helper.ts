import { HttpHeaders } from '@angular/common/http';
import { ORIGIN_URL } from '../constants/UTILS';

const createHeader = (token: string): HttpHeaders => {
  const headers = new HttpHeaders({
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': ORIGIN_URL,
  });
  return headers;
};

export { createHeader };
