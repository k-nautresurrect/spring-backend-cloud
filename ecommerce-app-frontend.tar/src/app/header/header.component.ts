import { Component } from '@angular/core';
import { UserAuthService } from '../service/user-auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.sass']
})
export class HeaderComponent {
  constructor(private userService: UserAuthService, private router: Router) {}

  public showLogout(): boolean{
    const userLoggedIn = this.userService.isLoggedIn();
    return userLoggedIn;
  }

  public logout(){
    this.userService.logout();
    this.router.navigateByUrl("/");
  }

  public getName(){
    return this.userService.getUserName();
  }
}
