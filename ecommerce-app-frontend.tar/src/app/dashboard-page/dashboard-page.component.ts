import { Component } from '@angular/core';
import { product, productInfo, publicProduct } from '../types/dataTypes';
import { ProductApiService } from '../api/product-api.service';
import { StatesService } from '../service/states.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-dashboard-page',
  templateUrl: './dashboard-page.component.html',
  styleUrls: ['./dashboard-page.component.sass']
})
export class DashboardPageComponent {
  serviceForm!: FormGroup;
  searchVal: string = '';

  constructor(private productApi: ProductApiService, public states: StatesService, private formBuilder: FormBuilder) {}
  
  ngOnInit() {
    this.productApi.getAll().subscribe({
      next: (v) => {
        this.states.productList.set([{
          productID: 0,
          productName: '',
          productCode: -1,
          brand: '',
          seller: false,
          user: {
            username: '',
            firstName: '',
            lastName: '',
            emailId: '',
          },
          details: {
            productDetailID: 0,
            price: -1,
            description: '',
            image: '',
          },
          pincodeList: [
            {
              pincode: -1,
              days: -1,
            },
          ],
        }])
        const productList  = v as product[];
        console.log(productList);
        productList.forEach((product: product) => {
          this.states.productList().push(product)
        })
        this.states.productList().shift();
      }
    })
    this.serviceForm = this.formBuilder.group({
      service: ['', Validators.pattern(/^\d+$/)]
    })
    
  }

  public handleModal(productID: number) {
    if(this.states.showModal() === false){
      this.states.showModal.set(true);
    } else {
      this.states.serviceMessage.set({text: ''});
      this.states.showModal.set(false);
    }
    this.states.productID.set(productID);
  }

  public onSubmit() {
    if (this.serviceForm?.invalid) {
      return;
    }
    const pincode = this.serviceForm?.value.service;
    const info: productInfo = {
      productID: this.states.productID(),
      pincode,
    }
    this.productApi.checkServicibility(info).subscribe({
      next: (v: any) => {
        this.states.serviceMessage.set({text: v.message})
      }
    })
    this.serviceForm.reset();
  }

  public searchResult() {
    this.productApi.userSearch(this.searchVal).subscribe({
      next: (v: any) => {
        this.states.productList.set([{
          productID: 0,
          productName: '',
          productCode: -1,
          brand: '',
          seller: false,
          user: {
            username: '',
            firstName: '',
            lastName: '',
            emailId: '',
          },
          details: {
            productDetailID: 0,
            price: -1,
            description: '',
            image: '',
          },
          pincodeList: [
            {
              pincode: -1,
              days: -1,
            },
          ],
        }])
        const productList  = v as product[];
        console.log(productList);
        productList.forEach((product: product) => {
          this.states.productList().push(product)
        })
        this.states.productList().shift();
        this.searchVal = '';
      }
    })
  }

  public onSearchText(event: any){
    this.searchVal += event.target.value;
  }
}
