import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.sass']
})
export class AddProductComponent {
  addProductForm!: FormGroup;

  constructor(private formBuilder: FormBuilder) {}

  ngOnInit () {
    this.addProductForm = this.formBuilder.group({
      productName: ['', Validators.required],
      productCode: ['', Validators.pattern(/^\d+$/)],
      brand: ['', Validators.required],
      price: ['', Validators.pattern(/^\d+$/)],
      description: ['', Validators.required],
      image: ['', Validators.required],
      pincode: ['', Validators.pattern(/^\d+$/)],
      days: ['', Validators.pattern(/^\d+$/)]
    });
  }

  public onSubmit() {
    console.log("submit function called");
  }
}
