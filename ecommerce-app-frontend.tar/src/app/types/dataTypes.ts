type userDetails = {
  username: string;
  firstName: string;
  lastName: string;
  emailID: string;
  role: string;
};

type userResponse = {
  role: {
    role: string;
  };
  message: {
    message: string;
    status: number;
  };
  user: {
    username: string;
    firstName: string;
    lastName: string;
    emailID: string;
  };
};

type userDetailsRequest = {
  userName: string;
  firstName: string;
  lastName: string;
  emailID: string;
  password: string;
  role: string;
};

type publicProduct = {
  productID: number;
  productName: string;
  productCode: string;
  brand: string;
};

type product = {
  productID: number;
  productName: string;
  productCode: number;
  brand: string;
  seller: boolean;
  user: {
    username: string;
    firstName: string;
    lastName: string;
    emailId: string;
  };
  details: {
    productDetailID: number;
    price: number;
    description: string;
    image: string;
  };
  pincodeList: [
    {
      pincode: number;
      days: number;
    }
  ];
};

type productInfo = {
    productID: number,
    pincode: number,
}

type message = {
    message: string,
    status: number,
}

// new types
type loginResponse = {
  message: message,
  userDetails: userDetails,
  token: token
}

type token = {
  token: string
}

type storedUser = {
  userDetails: userDetails,
  token: token,
}

type userLoginReq = {
  username: string,
  password: string,
}

export {
  userDetails,
  userResponse,
  userDetailsRequest,
  publicProduct,
  product,
  productInfo,
  message,
  loginResponse,
  token,
  storedUser,
  userLoginReq,
};
