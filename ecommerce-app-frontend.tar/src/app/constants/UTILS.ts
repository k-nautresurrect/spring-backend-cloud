const USER: string = 'USER';
const SELLER: string = 'SELLER'
const ORIGIN_URL: string = 'http://localhost:4200/';
const USER_ROLE: string = 'ROLE_USER';
const SELLER_ROLE: string = 'ROLE_SELLER';

export{USER, SELLER, ORIGIN_URL, USER_ROLE, SELLER_ROLE};