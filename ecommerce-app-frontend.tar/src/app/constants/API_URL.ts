const LOGIN: string = 'http://localhost:5500/api/public/login/';
const PRODUCT_FOR_USER: string = 'http://localhost:5500/api/user/products/get-all/';
const USER_REGISTER: string = 'http://localhost:5500/api/public/register/';
const PRODUCT_FOR_EVERYONE: string = 'http://localhost:5500/api/public/products/';
const SERVICE_URL: string = 'http://localhost:5500/api/user/service/';
const SEARCH_PUBLIC_URL: string = 'http://localhost:5500/api/public/products/search/'
const SEARCH_USER_URL: string = 'http://localhost:5500/api/user/products/search/';

export {LOGIN, PRODUCT_FOR_USER, USER_REGISTER, PRODUCT_FOR_EVERYONE, SERVICE_URL, SEARCH_PUBLIC_URL, SEARCH_USER_URL}