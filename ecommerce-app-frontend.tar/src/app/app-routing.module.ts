import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginFormComponent } from './login-form/login-form.component';
import { SignupFormComponent } from './signup-form/signup-form.component';
import { HomePageComponent } from './home-page/home-page.component';
import { DashboardPageComponent } from './dashboard-page/dashboard-page.component';
import { ProductPageComponent } from './product-page/product-page.component';
import { SellerDashboardComponent } from './seller-dashboard/seller-dashboard.component';
import { authGuard } from './service/auth.guard';
import { SELLER_ROLE, USER_ROLE } from './constants/UTILS';
import { ForbiddenComponent } from './forbidden/forbidden.component';
import { AddProductComponent } from './add-product/add-product.component';

const routes: Routes = [
  { path: '', component: HomePageComponent },
  { path: 'login', component: LoginFormComponent },
  { path: 'signup', component: SignupFormComponent },
  {
    path: 'dashboard',
    component: DashboardPageComponent,
    canActivate: [authGuard],
    data: { role: USER_ROLE },
  },
  { path: 'product/:id', component: ProductPageComponent },
  {
    path: 'seller-dashboard',
    component: SellerDashboardComponent,
    canActivate: [authGuard],
    data: { role: SELLER_ROLE },
  },
  {path: 'forbidden', component: ForbiddenComponent},
  {path: 'add-product', component: AddProductComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
