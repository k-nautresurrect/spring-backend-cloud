import { Component } from '@angular/core';
import { ProductApiService } from '../api/product-api.service';
import { productInfo, publicProduct } from '../types/dataTypes';
import { UserAuthService } from '../service/user-auth.service';
import { Router } from '@angular/router';
import { StatesService } from '../service/states.service';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.sass'],
})
export class HomePageComponent {
  productDetails: publicProduct[] = [];
  searchValue: string = '';
  constructor(
    private productApi: ProductApiService,
    private userService: UserAuthService,
    private router: Router,
    public states: StatesService
  ) {}
  ngOnInit() {
    if (this.userService.isLoggedIn()) {
      this.router.navigateByUrl('/login');
    }
    this.productApi.getAllPublic().subscribe({
      next: (v) => {
        this.states.productPbList.set([{
          productName: '',
          productCode: -1,
          brand: ''
        }])
        const productList  = v as any[];
        productList.forEach((product: any) => {
          this.states.productPbList().push(product)
        })
        if(this.states.productPbList().length >= 1){
          this.states.productPbList().shift();
        }
      },
    });
  }

  public searchResult() {
    // send this.searchValue to backend and search for the product
    this.productApi.publicSearch(this.searchValue).subscribe({
      next: (v) => {
        console.log(this.searchValue);
        console.log(v);
        const productList  = v as any[];
        this.states.productPbList.set([{
          productName: '',
          productCode: -1,
          brand: ''
        }])
        productList.forEach((product: any) => {
          this.states.productPbList().push(product)
        })
        if(this.states.productPbList().length >= 1){
          this.states.productPbList().shift();
        }
        this.searchValue = '';
      },
    })
  }

  public onSearchText(event: any){
    this.searchValue += event.target.value;
  }
}
