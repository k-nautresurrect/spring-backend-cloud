import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { userDetailsRequest } from '../types/dataTypes';
import { USER } from '../constants/UTILS';
import { SignupFormApiService } from '../api/signup-form-api.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup-form',
  templateUrl: './signup-form.component.html',
  styleUrls: ['./signup-form.component.sass'],
})
export class SignupFormComponent {
  signupForm!: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private signupApi: SignupFormApiService,
    private router: Router
  ) {}

  ngOnInit() {
    this.signupForm = this.formBuilder.group({
      userName: ['', Validators.required],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      emailId: ['', Validators.required],
      password: ['', Validators.required],
    });
  }

  public onSubmit() {
    if (this.signupForm?.invalid) {
      return;
    }
    const user: userDetailsRequest = {
      userName: this.signupForm?.value.userName,
      firstName: this.signupForm?.value.firstName,
      lastName: this.signupForm?.value.lastName,
      emailID: this.signupForm?.value.emailId,
      password: this.signupForm?.value.password,
      role: USER,
    };
    this.signupApi.registerUser(user).subscribe({
      next: (v) => {
        console.log(v);
        this.router.navigateByUrl("/login");
      } ,
      error: (err) => console.error,
    });
  }
}
