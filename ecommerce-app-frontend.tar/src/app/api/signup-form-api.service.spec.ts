import { TestBed } from '@angular/core/testing';

import { SignupFormApiService } from './signup-form-api.service';

describe('SignupFormApiService', () => {
  let service: SignupFormApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SignupFormApiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
