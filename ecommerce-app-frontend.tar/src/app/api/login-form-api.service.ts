import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { LOGIN } from '../constants/API_URL';
import { createHeader } from '../utils/helper';
import { userLoginReq } from '../types/dataTypes';
import { catchError, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class LoginFormApiService {
  constructor(private httpClient: HttpClient) {}

  loginUser(username: string, password: string) {
    const headers = createHeader("");
    const body: userLoginReq = {
      username,
      password
    }
    return this.httpClient.post(LOGIN,body, {headers});
  }
}
