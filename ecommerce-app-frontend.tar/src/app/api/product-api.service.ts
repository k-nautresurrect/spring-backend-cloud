import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {
  PRODUCT_FOR_EVERYONE,
  PRODUCT_FOR_USER,
  SEARCH_PUBLIC_URL,
  SEARCH_USER_URL,
  SERVICE_URL,
} from '../constants/API_URL';
import { productInfo, userDetails } from '../types/dataTypes';
import { createHeader } from '../utils/helper';

@Injectable({
  providedIn: 'root',
})
export class ProductApiService {
  constructor(private httpClient: HttpClient) {}

  getAll() {
    const user = JSON.parse(localStorage.getItem('user') as string);
    console.log(user);
    const headers = createHeader(user.token.token);
    return this.httpClient.get(PRODUCT_FOR_USER, { headers });
  }

  getAllPublic() {
    return this.httpClient.get(PRODUCT_FOR_EVERYONE);
  }

  getAccCode(code: string) {
    const user = JSON.parse(localStorage.getItem('user') as string);
    const headers = createHeader(user.token.token);
    const body = code;
    return this.httpClient.post(`${PRODUCT_FOR_USER}find/code/`, body, {
      headers,
    });
  }

  getAccName(name: string) {
    const user = JSON.parse(localStorage.getItem('user') as string);
    const headers = createHeader(user.token.token);
    const body = name;
    return this.httpClient.post(`${PRODUCT_FOR_USER}find/name/`, body, {
      headers,
    });
  }

  getAccBrand(brand: string) {
    const user = JSON.parse(localStorage.getItem('user') as string);
    const headers = createHeader(user.token.token);
    const body = brand;
    return this.httpClient.post(`${PRODUCT_FOR_USER}find/brand/`, body, {
      headers,
    });
  }

  getAccId(id: number) {
    const user = JSON.parse(localStorage.getItem('user') as string);
    const headers = createHeader(user.token.token);
    const body = id;
    return this.httpClient.post(`${PRODUCT_FOR_USER}find/id`, body, {
      headers,
    });
  }

  checkServicibility(info: productInfo) {
    const user = JSON.parse(localStorage.getItem('user') as string);
    const headers = createHeader(user.token.token);
    const body = info;
    return this.httpClient.post(`${SERVICE_URL}`, body, {
      headers,
    });
  }

  publicSearch(searchValue: string){
    const headers = createHeader('');
    return this.httpClient.post(`${SEARCH_PUBLIC_URL}`, searchValue, {headers});
  }

  userSearch(searchValue: string){
    const user = JSON.parse(localStorage.getItem('user') as string);
    const headers = createHeader(user.token.token);
    return this.httpClient.post(`${SEARCH_USER_URL}`, searchValue, {headers});
  }
}
