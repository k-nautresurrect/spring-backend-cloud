import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { userDetailsRequest } from '../types/dataTypes';
import { USER_REGISTER } from '../constants/API_URL';

@Injectable({
  providedIn: 'root',
})
export class SignupFormApiService {
  constructor(private httpClient: HttpClient) {}

  registerUser(userDetails: userDetailsRequest) {
    const body = userDetails;
    return this.httpClient.post(USER_REGISTER, body, {
      headers: {
        'Content-Type': 'application/json',
      },
    });
  }
}
