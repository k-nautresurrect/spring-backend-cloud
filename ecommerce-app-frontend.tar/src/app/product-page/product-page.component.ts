import { ChangeDetectorRef, Component, SimpleChange } from '@angular/core';
import { ProductApiService } from '../api/product-api.service';
import { ActivatedRoute } from '@angular/router';
import { message, product, productInfo } from '../types/dataTypes';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-product-page',
  templateUrl: './product-page.component.html',
  styleUrls: ['./product-page.component.sass'],
})
export class ProductPageComponent {
  id!: number;
  product!: product;
  serviceForm!: FormGroup;
  message!: message;
  checkServicability: boolean = true;
  prev!: boolean;

  constructor(
    private productApi: ProductApiService,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private cdr: ChangeDetectorRef,
  ) {}

  ngOnInit() {
    this.id = parseInt(this.route.snapshot.paramMap.get('id') as string);
    this.productApi.getAccId(this.id).subscribe({
      next: (v) => {
        this.product = v as product;
      },
    });
    this.serviceForm = this.formBuilder.group({
      service: ['', Validators.required],
    });
    this.prev = this.checkServicability;
  }

  onSubmit() {
    if (this.serviceForm?.invalid) {
      return;
    }
    const servicePinCode: number = parseInt(this.serviceForm?.value.service);
    const info: productInfo = {
      productID: this.id,
      pincode: servicePinCode,
    };
    this.productApi.checkServicibility(info).subscribe({
      next: (v) => {
        this.message = v as message;
        console.log(this.message)
      },
    });
    this.checkServicability = false;
  }

  handleServicability() {
    this.checkServicability = true;
  }

  ngOnChange(){
    console.log("prev ", this.prev);
    console.log("check ", this.checkServicability);
    if(this.prev !== this.checkServicability){
      this.prev = this.checkServicability;
    }
    this.cdr.detectChanges;
  }
}
