import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

import { LoginFormApiService } from '../api/login-form-api.service';
import {
  loginResponse,
  storedUser,
  userDetails,
  userResponse,
} from '../types/dataTypes';
import { ProductApiService } from '../api/product-api.service';
import { Route, Router } from '@angular/router';
import { USER_ROLE } from '../constants/UTILS';
import { UserAuthService } from '../service/user-auth.service';
import { StatesService } from '../service/states.service';

@Component({
  selector: 'app-login-form',
  templateUrl: './login-form.component.html',
  styleUrls: ['./login-form.component.sass'],
})
export class LoginFormComponent {
  loginForm!: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private loginFormApi: LoginFormApiService,
    private router: Router,
    private userService: UserAuthService,
    public states: StatesService,
  ) {}

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
    });
    if (this.userService.isLoggedIn()) {
      const role: string | null = this.userService.getRole();
      role === USER_ROLE
        ? this.router.navigateByUrl('/dashboard')
        : this.router.navigateByUrl('/seller-dashboard');
    }
  }

  onSubmit() {
    if (this.loginForm?.invalid) {
      return;
    }
    const username = this.loginForm?.value.username;
    const password = this.loginForm?.value.password;

    this.loginFormApi.loginUser(username, password).subscribe({
      next: async (res) => {
        this.storeUser(res as loginResponse);
      },
      error: (err) => this.handleError(err),
    });
  }

  private storeUser(data: loginResponse) {
    const { userDetails, token } = data;
    const user: storedUser = { userDetails, token };
    localStorage.setItem('user', JSON.stringify(user));
    console.log(localStorage.getItem('user'));
    const userPresent =
      (JSON.parse(localStorage.getItem('user') as string) as loginResponse)
        .token !== null
        ? true
        : false;

    if (!userPresent) {
      this.states.loginError.mutate((value) => {
        value.status = 1;
        value.text = "please check username and password"
      })
      return;
    }

    const details: userDetails = (
      JSON.parse(localStorage.getItem('user') as string) as loginResponse
    ).userDetails;
    details.role === USER_ROLE
      ? this.router.navigateByUrl('/dashboard')
      : this.router.navigateByUrl('/seller-dashboard');
  }

  private handleError(err: any) {
    if (err.status === 403) {
      this.states.loginError.mutate((value) => {
        value.status = 0;
        value.text = 'Wrong password';
      });
    }
  }
}
