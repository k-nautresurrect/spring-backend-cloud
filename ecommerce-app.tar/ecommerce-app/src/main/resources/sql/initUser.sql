use ecommerce_management;

drop table if exists `authorities`;
drop table if exists `users`;

create table `users` (
	`username` varchar(255) not null,
    `password` varchar(255) not null,
    `enabled` tinyint not null,
    primary key(`username`)
    ) engine = InnoDB default charset = latin1;

create table `authorities` (
	`username` varchar(255) not null,
    `authority` varchar(255) not null,
    unique key `authorities_idx_1` (`username`, `authority`),
    constraint `authorities_ibfk_1` foreign key (`username`) references `users` (`username`)
    ) engine = InnoDB default charset = latin1;