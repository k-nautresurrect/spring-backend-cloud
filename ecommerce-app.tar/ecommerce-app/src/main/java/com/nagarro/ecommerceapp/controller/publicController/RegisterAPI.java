package com.nagarro.ecommerceapp.controller.publicController;

import com.nagarro.ecommerceapp.dto.*;
import com.nagarro.ecommerceapp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/*
*
*  API end point available for public i.e. without authentication
*    provides functionality to register a new user and take credentials
*    for logging in a new user.
*    the users can have 3 role
*    USER, ADMIN, SELLER
*
* */

@RestController
@RequestMapping("api/public/")
public class RegisterAPI {
    private final UserService userService;
    @Autowired
    public RegisterAPI(UserService userService){
        this.userService = userService;
    }
    /*
    *
    *   Register a new user by providing fields
    *   username, password, firstname, lastname, role, emailId
    *   username should be unique.
    *   this endpoint will give the message of successful or unsuccessful
    *   registration.
    *
    * */
    @PostMapping("register/")
    public Message registerUser(@RequestBody UserInfo userInfo) {
        return userService.createUser(userInfo);
    }
    /*
    *
    *   Login an existing user by credentials of the user as
    *   username, password
    *   this endpoint will return an jwtToken which is to be used
    *   to authenticate and authorize the user.
    *
    * */
    @PostMapping("login/")
    public Map<String, Object> loginUser(@RequestBody User userCredentials) {
        Map<String, Object> mp = new HashMap<>();
        com.nagarro.ecommerceapp.model.User u =
                userService.getUser(userCredentials.getUsername());
        if(u != null){
            TokenResponse token = userService.loginUser(userCredentials);
            UserDetailsInfo userDetailsInfo = new UserDetailsInfo(u.getUsername(),
                    u.getFirstName(), u.getLastName(), u.getEmailId(), u.getRole());
            Send.message.set("login Successful", 1);
            mp.put("message", Send.message);
            mp.put("token", token);
            mp.put("userDetails", userDetailsInfo);
            return mp;
        }
        Send.message.set("user don't exist check user name", 0);
        mp.put("message", Send.message);
        mp.put("details", null);
        mp.put("token", null);
        return mp;
    }

    @GetMapping("logout/")
    public Message logoutUser(){
        try {
            SecurityContextHolder.getContext().setAuthentication(null);
            Send.message.set("logout successfull", 1);
            return Send.message;
        }catch (Exception e){
            System.out.println(e);
        }
        Send.message.set("something went wrong", 0);
        return Send.message;
    }
}
