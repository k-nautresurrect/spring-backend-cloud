package com.nagarro.ecommerceapp.controller.secureController.user;

import com.nagarro.ecommerceapp.config.service.JwtService;
import com.nagarro.ecommerceapp.dto.Send;
import com.nagarro.ecommerceapp.dto.UserDetailsInfo;
import com.nagarro.ecommerceapp.model.Product;
import com.nagarro.ecommerceapp.model.User;
import com.nagarro.ecommerceapp.repository.UserRepository;
import com.nagarro.ecommerceapp.service.ProductService;
import com.nagarro.ecommerceapp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/*
*
*   API endpoints to get the products which are available for user
*   secured api user endpoint for access to USER role only verified
*   by principle from jwt token and role configuration
*
* */


@RestController
@RequestMapping("api/user/")
public class UserAPI {
    private final UserService userService;
    private final ProductService productService;

    @Autowired
    public UserAPI(UserService userService, ProductService productService) {
        this.userService = userService;
        this.productService = productService;
    }

    // test route
    @GetMapping("get-all/")
    public List<User> checkAPI() {
        return userService.getAllUsers();
    }

    @GetMapping("products/get-all/")
    public List<Product> getProducts() {
        return productService.getAllForUser();
    }

}
