package com.nagarro.ecommerceapp.controller.secureController.user;

import com.nagarro.ecommerceapp.dto.PriceRange;
import com.nagarro.ecommerceapp.dto.ProductInfo;
import com.nagarro.ecommerceapp.model.Product;
import com.nagarro.ecommerceapp.model.ProductDetails;
import com.nagarro.ecommerceapp.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

/*
*
*   API endpoints on product for users
*   govern the operation that can be performed
*   on the products seen by user
*
* */


@RestController
@RequestMapping("api/user/products/")
public class UserProductAPI {
    private final ProductService productService;

    @Autowired
    public UserProductAPI(ProductService productService) {
        this.productService = productService;
    }

    @PostMapping("find/code/")
    public List<Product> findByCode(@RequestBody String code){
        return productService.getProductsAccCode(code);
    }

    @PostMapping("find/brand/")
    public List<Product> findByBrand(@RequestBody String brand){
        return productService.getProductsAccBrand(brand);
    }

    @PostMapping("find/name/")
    public List<Product> findByName(@RequestBody String name){
        return productService.getProductsAccName(name);
    }

    @PostMapping("find/id")
    public Product findByID(@RequestBody Long id) {
        return productService.getProductById(id);
    }

    @PostMapping("get-price")
    public List<Product> findByPrice(@RequestBody PriceRange priceRange){
        List<ProductDetails> details = productService.getProductByPrice(priceRange);
        List<Product> products = new ArrayList<>();
        for(ProductDetails pd: details) {
            Product p = productService.getProductByProductDetail(pd);
            products.add(p);
        }
        return products;
    }


    @PostMapping("search/")
    public List<Product> searchProduct(@RequestBody String searchValue){
        String val = searchValue.trim();
        return this.productService.search(val);
    }
}
