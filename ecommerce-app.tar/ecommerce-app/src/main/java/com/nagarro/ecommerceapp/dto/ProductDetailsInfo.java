package com.nagarro.ecommerceapp.dto;

import java.util.List;

public class ProductDetailsInfo {
    private UserDetailsInfo user;
    private String productName;
    private Long productCode;
    private String brand;
    ProductAdditionalInfo details;
    List<PinCodeInfo> pinCodeList;

    public ProductDetailsInfo() {}
    public ProductDetailsInfo(String productName,
                              UserDetailsInfo user,
                              Long productCode,
                              String brand,
                              ProductAdditionalInfo details,
                              List<PinCodeInfo> pinCodeList) {
        this.productName = productName;
        this.productCode = productCode;
        this.brand = brand;
        this.details = details;
        this.pinCodeList = pinCodeList;
        this.user = user;
    }

    public UserDetailsInfo getUser() {
        return user;
    }

    public void setUser(UserDetailsInfo user) {
        this.user = user;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Long getProductCode() {
        return productCode;
    }

    public void setProductCode(Long productCode) {
        this.productCode = productCode;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public ProductAdditionalInfo getDetails() {
        return details;
    }

    public void setDetails(ProductAdditionalInfo details) {
        this.details = details;
    }

    public List<PinCodeInfo> getPinCodeList() {
        return pinCodeList;
    }

    public void setPinCodeList(List<PinCodeInfo> pinCodeList) {
        this.pinCodeList = pinCodeList;
    }

}
