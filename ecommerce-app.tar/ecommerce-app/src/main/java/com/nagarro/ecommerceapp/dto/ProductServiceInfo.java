package com.nagarro.ecommerceapp.dto;

public class ProductServiceInfo {
    private Long productID;
    private String pincode;

    public ProductServiceInfo() {}
    public ProductServiceInfo(Long productID, String pincode) {
        this.productID = productID;
        this.pincode = pincode;
    }

    public Long getProductID() {
        return productID;
    }

    public void setProductID(Long productID) {
        this.productID = productID;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }
}
