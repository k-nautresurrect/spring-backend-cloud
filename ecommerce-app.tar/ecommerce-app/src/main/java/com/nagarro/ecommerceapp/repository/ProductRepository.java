package com.nagarro.ecommerceapp.repository;

import com.nagarro.ecommerceapp.model.Product;
import com.nagarro.ecommerceapp.model.ProductDetails;
import com.nagarro.ecommerceapp.model.User;
import jakarta.persistence.Transient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface ProductRepository extends JpaRepository<Product, Long> {
    @Transactional
    @Modifying
    @Transient
    int deleteByProductID(Long productID);
    @Query("select p from Product p where p.productCode = :code")
    List<Product> findByCode(@Param("code") String code);

    @Query("select p from Product p where p.brand = :brand")
    List<Product> findByBrand(@Param("brand") String brand);

    @Query("select p from Product p where p.productName = :name")
    List<Product> findByName(@Param("name") String name);

    @Query("select p from Product p where p.productID = :id")
    Product findAccID(@Param("id") Long id);

    @Query("select p from Product p where p.user = user")
    List<Product> findByUser(@Param("user") User user);

    @Query("select p from Product p where p.seller = true")
    List<Product> findAllAvailForSale();

    @Query("select p from Product p where p.details = :pd")
    Product findByProductDetails(@Param("pd") ProductDetails pd);

    @Query("select p from Product p where p.productCode like :val% or p.productName like :val% or p.brand like :val%")
    List<Product> search(String val);

    List<Product> findByProductNameContainingIgnoreCaseOrBrandContainingIgnoreCase(String val1, String val2);
}
