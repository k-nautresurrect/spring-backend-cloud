package com.nagarro.ecommerceapp.service;

import com.nagarro.ecommerceapp.dto.*;
import com.nagarro.ecommerceapp.model.PinCode;
import com.nagarro.ecommerceapp.model.Product;
import com.nagarro.ecommerceapp.model.ProductDetails;
import com.nagarro.ecommerceapp.model.User;
import com.nagarro.ecommerceapp.repository.PinCodeRepository;
import com.nagarro.ecommerceapp.repository.ProductDetailsRepository;
import com.nagarro.ecommerceapp.repository.ProductRepository;
import com.nagarro.ecommerceapp.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ProductService {
    private final ProductRepository productRepository;
    private final ProductDetailsRepository productDetailsRepository;
    private final PinCodeRepository pinCodeRepository;
    private final UserRepository userRepository;

    @Autowired
    public ProductService(ProductRepository productRepository,
                          ProductDetailsRepository productDetailsRepository,
                          PinCodeRepository pinCodeRepository,
                          UserRepository userRepository){
        this.pinCodeRepository = pinCodeRepository;
        this.productRepository = productRepository;
        this.productDetailsRepository = productDetailsRepository;
        this.userRepository = userRepository;
    }

    public Message add(ProductDetailsInfo info) {
        Product product = new Product(info.getProductName(), info.getProductCode(), info.getBrand());
        product.setSeller(true);
        product.setUser(userRepository.findByUsername(info.getUser().getUserName()));
        ProductDetails details = new ProductDetails(info.getDetails().getPrice(),
                info.getDetails().getDescription(), product);
        try {
            details.setImage(info.getDetails().getImage());
            productRepository.save(product);
            for(PinCodeInfo codes: info.getPinCodeList()){
                PinCode code = new PinCode(codes.getPincode(), product);
                code.setDays(codes.getDays());
                pinCodeRepository.save(code);
            }
            productDetailsRepository.save(details);
            Send.message.set("added product successfully", 1);
            return Send.message;
        }catch (Exception e) {
            System.out.println(e);
        }
        Send.message.set("product is not added", 0);
        return Send.message;
    }

    public List<ProductInfo> getAll() {
        List<Product>  ls = productRepository.findAll();
        List<ProductInfo> products = new ArrayList<>();
        for(Product product: ls){
            ProductInfo info = new ProductInfo(product.getProductName(),
                    String.valueOf(product.getProductCode()),
                    product.getBrand());
            products.add(info);
        }
        return products;
    }

    public List<ProductDetailsInfo> getProductsAccSeller(User user) {
        List<Product> ls = this.getProductsBySeller(user);
        List<ProductDetailsInfo> productDetailsInfoList = new ArrayList<>();
        for(Product product: ls){
            UserDetailsInfo userInfo = new UserDetailsInfo(
                    product.getUser().getUsername(),
                    product.getUser().getFirstName(),
                    product.getUser().getLastName(),
                    product.getUser().getEmailId(),
                    product.getUser().getRole());
            ProductAdditionalInfo productAdditionalInfo = new ProductAdditionalInfo(
                    product.getDetails().getPrice(),
                    product.getDetails().getDescription(),
                    product.getDetails().getImage()
            );
            List<PinCodeInfo> pinCodeInfoList = new ArrayList<>();
            for(PinCode pin: product.getPinCodeList()){
                PinCodeInfo pinInfo = new PinCodeInfo(pin.getPincode(), pin.getDays());
                pinCodeInfoList.add(pinInfo);
            }
            ProductDetailsInfo info = new ProductDetailsInfo(product.getProductName(),
                    userInfo,
                    product.getProductCode(),
                    product.getBrand(),
                    productAdditionalInfo,
                    pinCodeInfoList
            );
            productDetailsInfoList.add(info);
        }
        return productDetailsInfoList;
    }

    private List<Product> getProductsBySeller(User user) {
        return productRepository.findByUser(user);
    }

    public List<Product> getProductsAccCode(String code) {
        return productRepository.findByCode(code);
    }

    public List<Product> getProductsAccBrand(String brand) {
        return productRepository.findByBrand(brand);
    }

    public List<Product> getProductsAccName(String name) {
        return productRepository.findByName(name);
    }

    public Product getProductById(Long id) {
        return productRepository.findAccID(id);
    }

    public Product updateProduct(ProductDetailsInfo info, Long id) {
        ProductAdditionalInfo detailsInfo = info.getDetails();
        List<PinCodeInfo> ls = info.getPinCodeList();

        Product product = productRepository.findAccID(id);
        ProductDetails details = new ProductDetails(detailsInfo.getPrice(),
                detailsInfo.getDescription(), product);
        details.setImage(detailsInfo.getImage());
        int updatedDetails = productDetailsRepository.updateByID(details, product);

        for(PinCodeInfo pin: ls){
            int updatedCode = pinCodeRepository.updateByProductAndCode(pin.getPincode(), pin.getDays(), product);
        }
        return productRepository.findAccID(id);
    }

    public Message delete(Long id) {
        try {
            Product product = productRepository.findAccID(id);
            long lp = pinCodeRepository.deleteByProductPinCode(product);
            long ld = productDetailsRepository.deleteByProduct(product);
            int l = productRepository.deleteByProductID(id);
            Send.message.set("deleted successfully", 1);
            return Send.message;
        }catch (Exception e){
            Send.message.set("delete operation failed", 0);
            return Send.message;
        }
    }

    public List<Product> getAllForUser() {
        return productRepository.findAllAvailForSale();
    }

    public List<ProductDetails> getProductByPrice(PriceRange priceRange) {
        return productDetailsRepository.getProductsByPrice(priceRange.getStart(), priceRange.getEnd());
    }

    public Product getProductByProductDetail(ProductDetails pd) {
        return productRepository.findByProductDetails(pd);
    }

    public List<Product> search(String val) {
        return this.productRepository.search(val);
    }
}
