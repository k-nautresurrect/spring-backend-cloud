package com.nagarro.ecommerceapp.utils;

public interface UserQuery {
    String getExactRole(String role);
    String getExactUserName(String username);
    String getEncodedPassword(String password);
    String getUserRoleByUsername(String username);
}
