package com.nagarro.ecommerceapp.repository;

import com.nagarro.ecommerceapp.dto.PriceRange;
import com.nagarro.ecommerceapp.model.Product;
import com.nagarro.ecommerceapp.model.ProductDetails;
import jakarta.persistence.Transient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface ProductDetailsRepository extends JpaRepository<ProductDetails, Long> {

    @Transient
    @Modifying
    @Transactional
    long deleteByProduct(Product product);

    @Transient
    @Transactional
    @Modifying
    @Query("update ProductDetails p set p.price = :#{#details.price}, p.description = :#{#details.description}," +
            "p.image = :#{#details.image} where p.product = :product")
    int updateByID(@Param("details") ProductDetails details, @Param("product") Product product);

    @Query("select pd from ProductDetails pd where pd.price >= :start and pd.price <= :end")
    List<ProductDetails> getProductsByPrice(@Param("start") Long start, @Param("end") Long end);
}
