package com.nagarro.ecommerceapp.service.authentication;

import com.nagarro.ecommerceapp.dto.TokenResponse;
import com.nagarro.ecommerceapp.dto.UserInfo;
import com.nagarro.ecommerceapp.model.User;
import com.nagarro.ecommerceapp.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {
    private final UserRepository userRepository;

    public AuthService(UserRepository userRepository){
        this.userRepository = userRepository;
    }
}
