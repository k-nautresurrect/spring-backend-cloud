package com.nagarro.ecommerceapp.dto;

public class ProductInfo {
    private String productName;
    private String productCode;
    private String brand;

    public ProductInfo() {}

    public ProductInfo(String productName, String productCode, String brand) {
        this.brand = brand;
        this.productName = productName;
        this.productCode = productCode;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }
}
