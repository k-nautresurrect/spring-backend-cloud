package com.nagarro.ecommerceapp.service;

import com.nagarro.ecommerceapp.config.service.JwtService;
import com.nagarro.ecommerceapp.dto.*;
import com.nagarro.ecommerceapp.model.User;
import com.nagarro.ecommerceapp.repository.UserRepository;
import com.nagarro.ecommerceapp.utils.UserQuery;
import com.nagarro.ecommerceapp.utils.UserQueryImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class UserService {
    private final UserQuery userQuery;
    private final UserRepository userRepository;
    private final JwtService jwtService;
    private final AuthenticationManager authenticationManager;

    @Autowired
    public UserService(UserRepository userRepository, JwtService jwtService, AuthenticationManager authenticationManager) {
        this.userQuery = new UserQueryImpl();
        this.userRepository = userRepository;
        this.jwtService = jwtService;
        this.authenticationManager = authenticationManager;
    }

    /*
    *
    *   this method creates a new user in the database and returns a message having
    *   message: the text prompt which determines the user is created or not
    *   status:  either 0, 1, which act as boolean
    *
    * */
    public Message createUser(UserInfo userInfo) {
        if(userRepository.findByUsername(userInfo.getUserName()) == null){
            User info = new User(
                    userInfo.getUserName(),
                    userInfo.getFirstName(),
                    userInfo.getLastName(),
                    userInfo.getEmailID(),
                    encodePassword(userInfo.getPassword()),
                    getExactRole(userInfo.getRole())
            );
            userRepository.save(info);
            Send.message.set("registered successfully", 1);
            return Send.message;
        }
        Send.message.set("user already exist", 0);
        return Send.message;
    }
    /**
     *
     *  this method will give us the token for the given credentials
     *  and authenticate the user if the user is authenticated
     *  it will return the Token object having a property of token
     *  which represent the jwt token for that user, if not it will throw
     *  a response of 403 forbidden
     *
     * */
    public TokenResponse loginUser(com.nagarro.ecommerceapp.dto.User info){
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(info.getUsername(), info.getPassword())
        );
        User user = userRepository.findByUsername(info.getUsername());
        String token = jwtService.generateToken(user);
        return new TokenResponse(token);
    }

    public List<User> getAllUsers() {
        List<User> userList = userRepository.findAll();
        return userList;
    }

    public User getUser(String username) {
        return userRepository.findByUsername(username);
    }

//    public Role getRoleForUser(String username) {
//        Role role = new Role();
//        RowMapper<Role> rowMapper = (result, num) -> {
//            role.setRole(result.getString("authority"));
//            return role;
//        };
//        jdbcTemplate.query(userQuery.getUserRoleByUsername(username), rowMapper);
//        return role;
//    }

    public String encodePassword(String password) {
        return userQuery.getEncodedPassword(password);
    }

    public String getExactUserName(String username) {
        return userQuery.getExactUserName(username);
    }

    public String getExactRole(String role) {
        return userQuery.getExactRole(role);
    }

}
