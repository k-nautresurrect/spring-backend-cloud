package com.nagarro.ecommerceapp.model;

import jakarta.persistence.*;

@Entity
@Table(name = "product_details")
public class ProductDetails {
    // fields for product details
    @Id
    @Column(name = "product_detail_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long productDetailID;
    @Column(name = "price")
    private Integer price;
    @Column(name = "description")
    private String description;
    @Column(name = "image")
    private String image;

    // mappings
    @OneToOne
    @JoinColumn(name = "product_id")
    private Product product;

    public ProductDetails() {}
    public ProductDetails(Integer price, String description, Product product) {
        this.product = product;
        this.price = price;
        this.description = description;
    }

    public Long getProductDetailID() {
        return productDetailID;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
