package com.nagarro.ecommerceapp.repository;

import com.nagarro.ecommerceapp.model.PinCode;
import com.nagarro.ecommerceapp.model.Product;
import jakarta.persistence.Transient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface PinCodeRepository extends JpaRepository<PinCode, Long> {

    @Transient
    @Modifying
    @Transactional
    long deleteByProductPinCode(Product productPinCode);
    @Query("select p from PinCode p where p.productPinCode = :product")
    List<PinCode> findByProduct(@Param("product") Product product);

    @Transient
    @Transactional
    @Modifying
    @Query("update PinCode p set p.pincode = :pincode, p.days = :days where p.productPinCode = :product")
    int updateByProductAndCode(@Param("pincode") String pincode, @Param("days") Integer days, @Param("product") Product product);
}
