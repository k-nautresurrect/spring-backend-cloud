# task 1
- jwt token authentication [x]
- registerAPI with jwt token done [x]