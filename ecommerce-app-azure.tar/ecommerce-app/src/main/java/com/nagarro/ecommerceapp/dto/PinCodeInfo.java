package com.nagarro.ecommerceapp.dto;

public class PinCodeInfo {
    private String pincode;
    private Integer days;

    public PinCodeInfo() {}
    public PinCodeInfo(String pincode, Integer days) {
        this.pincode = pincode;
        this.days = days;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public Integer getDays() {
        return days;
    }

    public void setDays(Integer days) {
        this.days = days;
    }
}
