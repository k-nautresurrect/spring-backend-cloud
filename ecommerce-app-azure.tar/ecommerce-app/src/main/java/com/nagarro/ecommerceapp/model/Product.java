package com.nagarro.ecommerceapp.model;

import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name = "products")
public class Product {
    // product fields
    @Id
    @Column(name = "product_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long productID;
    @Column(name = "product_name")
    private String productName;
    @Column(name = "product_code", unique = true)
    private Long productCode;
    @Column(name = "brand")
    private String brand;
    @Column(name = "seller")
    private Boolean seller;
    // mapping
    @ManyToOne
    @JoinColumn(name = "username")
    User user;
    @OneToOne(mappedBy = "product", cascade = CascadeType.ALL)
    ProductDetails details;
    @OneToMany(mappedBy = "productPinCode", cascade = CascadeType.ALL)
    List<PinCode> pinCodeList;

    public Product() {}

    public Product(String productName, Long productCode, String brand) {
        this.productName = productName;
        this.productCode = productCode;
        this.brand = brand;
    }

    public Long getProductID() {
        return productID;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Long getProductCode() {
        return productCode;
    }

    public void setProductCode(Long productCode) {
        this.productCode = productCode;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public ProductDetails getDetails() {
        return details;
    }

    public void setDetails(ProductDetails details) {
        this.details = details;
    }

    public List<PinCode> getPinCodeList() {
        return pinCodeList;
    }

    public void setPinCodeList(List<PinCode> pinCodeList) {
        this.pinCodeList = pinCodeList;
    }

    public Boolean getSeller() {
        return seller;
    }

    public void setSeller(Boolean seller) {
        this.seller = seller;
    }
}
