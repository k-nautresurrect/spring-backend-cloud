package com.nagarro.ecommerceapp.controller.secureController.user;

import com.nagarro.ecommerceapp.dto.Message;
import com.nagarro.ecommerceapp.dto.ProductServiceInfo;
import com.nagarro.ecommerceapp.dto.Send;
import com.nagarro.ecommerceapp.model.PinCode;
import com.nagarro.ecommerceapp.model.Product;
import com.nagarro.ecommerceapp.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("api/user/service/")
public class ProductServicibilityAPI {
    private final ProductService productService;

    @Autowired
    public ProductServicibilityAPI(ProductService productService) {
        this.productService = productService;
    }
    @PostMapping("")
    public Message getServicibility(@RequestBody ProductServiceInfo info) {
        Product product = this.productService.getProductById(info.getProductID());
        List<PinCode> pincodes = product.getPinCodeList();
        for(PinCode code: pincodes){
            if(code.getPincode().trim().equalsIgnoreCase(info.getPincode())){
                String msg = "available and will be delivered in "+code.getDays() + " days";
                Send.message.set(msg, 1);
                return Send.message;
            }
        }
        Send.message.set("the service for this product is not available now", 0);
        return Send.message;
    }

}
