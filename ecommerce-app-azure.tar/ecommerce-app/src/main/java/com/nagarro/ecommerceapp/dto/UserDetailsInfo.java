package com.nagarro.ecommerceapp.dto;

public class UserDetailsInfo {
    private String userName;
    private String firstName;
    private String lastName;
    private String emailID;
    private String role;

    public UserDetailsInfo() {}

    public UserDetailsInfo(String userName, String firstName, String lastName, String emailID, String role) {
        this.userName = userName;
        this.firstName = firstName;
        this.lastName = lastName;
        this.emailID = emailID;
        this.role = role;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmailID() {
        return emailID;
    }

    public void setEmailID(String emailID) {
        this.emailID = emailID;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
