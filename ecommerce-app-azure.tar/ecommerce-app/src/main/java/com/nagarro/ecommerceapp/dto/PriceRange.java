package com.nagarro.ecommerceapp.dto;

public class PriceRange {
    private Long start;
    private Long end;

    public PriceRange(Long start, Long end) {
        this.start = start;
        this.end = end;
    }

    public Long getStart() {
        return start;
    }

    public void setStart(Long start) {
        this.start = start;
    }

    public Long getEnd() {
        return end;
    }

    public void setEnd(Long end) {
        this.end = end;
    }
}
