package com.nagarro.ecommerceapp.dto;

public interface Send {
    Message message = new Message();
}
