package com.nagarro.ecommerceapp.controller.publicController;

import com.nagarro.ecommerceapp.dto.ProductInfo;
import com.nagarro.ecommerceapp.model.Product;
import com.nagarro.ecommerceapp.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

/*
*
*   API endpoint for displaying the required information on the
*   homepage returns a list of products that are added by the SELLER
*   these products have restricted information of
*   product name, product code, product brand
*
* */
@RestController
@RequestMapping("api/public/products/")
public class ProductAPI {
    private final ProductService productService;

    @Autowired
    public ProductAPI(ProductService productService){
        this.productService = productService;
    }
    @GetMapping("")
    public List<ProductInfo> getAll() {
        return this.productService.getAll();
    }

    @PostMapping("search/")
    public List<ProductInfo> searchProduct(@RequestBody String searchValue){
        String val = searchValue.trim();
        List<Product> ls =  this.productService.search(val);
        List<ProductInfo> infoList = new ArrayList<>();
        for(Product p: ls){
            ProductInfo info = new ProductInfo(p.getProductName(), String.valueOf(p.getProductCode()), p.getBrand());
            infoList.add(info);
        }
        return infoList;
    }
}
