package com.nagarro.ecommerceapp.utils;

public enum Roles {
    USER,
    ADMIN,
    SELLER
}
