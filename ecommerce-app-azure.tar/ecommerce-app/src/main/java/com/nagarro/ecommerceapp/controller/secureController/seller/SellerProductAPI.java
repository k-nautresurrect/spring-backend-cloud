package com.nagarro.ecommerceapp.controller.secureController.seller;

import com.nagarro.ecommerceapp.dto.Message;
import com.nagarro.ecommerceapp.dto.ProductDetailsInfo;
import com.nagarro.ecommerceapp.dto.ProductInfo;
import com.nagarro.ecommerceapp.dto.Send;
import com.nagarro.ecommerceapp.model.Product;
import com.nagarro.ecommerceapp.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/*
*
*   API endpoints for CRUD operations on product by seller
*
* */

@RestController
@RequestMapping("api/seller/products/")
public class SellerProductAPI {
    private final ProductService productService;

    @Autowired
    public SellerProductAPI(ProductService productService){
        this.productService = productService;
    }
    @PostMapping(value = "add-product/")
    public Message addProduct(@RequestBody() ProductDetailsInfo info) {
        return productService.add(info);
    }
    @PostMapping("update-product/{id}")
    public Message updateProduct(@RequestBody ProductDetailsInfo info, @PathVariable Long id){
        Product p = productService.updateProduct(info, id);
        if(p != null){
            Send.message.set("updated product successfully", 1);
            return Send.message;
        }
        Send.message.set("product is not updated", 0);
        return Send.message;
    }
    @GetMapping("delete-product/{id}")
    public Message deleteProduct(@PathVariable Long id){
        return productService.delete(id);
    }
}
