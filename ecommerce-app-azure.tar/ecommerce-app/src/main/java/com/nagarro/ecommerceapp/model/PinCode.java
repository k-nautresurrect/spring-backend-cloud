package com.nagarro.ecommerceapp.model;

import jakarta.persistence.*;

@Entity
@Table(name = "pincode")
public class PinCode {
    // fields for pincode
    @Id
    @Column(name = "pincode_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long pinCodeID;
    @Column(name = "pincode")
    private String pincode;
    @Column(name = "delivery_time")
    private Integer days;

    // mappings
    @ManyToOne
    @JoinColumn(name ="product_id")
    Product productPinCode;

    public PinCode() {}

    public PinCode(String pincode, Product productPinCode) {
        this.productPinCode = productPinCode;
        this.pincode = pincode;
    }

    public String getPincode() {
        return pincode;
    }
    public void setPincode(String pincode) {
        this.pincode = pincode;
    }
    public Integer getDays() {
        return days;
    }
    public void setDays(Integer days) {
        this.days = days;
    }
}
