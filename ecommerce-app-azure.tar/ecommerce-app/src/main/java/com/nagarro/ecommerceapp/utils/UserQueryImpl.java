package com.nagarro.ecommerceapp.utils;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

public class UserQueryImpl implements UserQuery {
    private final PasswordEncoder encoder = new BCryptPasswordEncoder(12);

    @Override
    public String getUserRoleByUsername(String username) {
        return "select authority from authorities where username = '"+ username +"'";
    }
    @Override
    public String getExactRole(String role) {
        return "ROLE_"+ role.trim().toUpperCase();
    }

    @Override
    public String getExactUserName(String username) {
        return username.trim();
    }

    @Override
    public String getEncodedPassword(String password) {
        return encoder.encode(password.trim());
    }
}
