package com.nagarro.ecommerceapp.controller.secureController.seller;

import com.nagarro.ecommerceapp.dto.*;
import com.nagarro.ecommerceapp.model.PinCode;
import com.nagarro.ecommerceapp.model.Product;
import com.nagarro.ecommerceapp.model.User;
import com.nagarro.ecommerceapp.service.ProductService;
import com.nagarro.ecommerceapp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/*
*
*   API end points for seller dashboard provides all the products of seller
*   the details of this product consist of
*   seller details, the product is available to sell or not
*   the pin codes that product is available for
*
* */
@RestController
@RequestMapping("api/seller/")
public class SellerAPI {
    private final UserService userService;
    private final ProductService productService;
    @Autowired
    public SellerAPI(UserService userService, ProductService productService){
        this.userService = userService;
        this.productService = productService;
    }

    /**
     *
     * this method returns a list of products that are there to be sold
     * by seller
     *
     * */
    @GetMapping("products/get-all/")
    public List<ProductDetailsInfo> sellerProductList(@RequestBody String username) {
        User u = userService.getUser(username);
        return productService.getProductsAccSeller(u);
    }
}
